package com.example.a201b335;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textview;
    SharedPreferences sharedPreferences;
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case R.id.eng:
                textview.setText("English");
                sharedPreferences.edit().putString("title","Hindi").apply();
                return true;
            case R.id.hin:
                textview.setText("Hindi");
                sharedPreferences.edit().putString("title","Hindi").apply();
                return true;
            case R.id.urd:
                textview.setText("Urdu");
                sharedPreferences.edit().putString("title","Urdu").apply();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean onCreatePanelMenu(int featureId, @NonNull Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview=findViewById(R.id.textview);
        sharedPreferences=this.getSharedPreferences("com.example.a201b335",0);
        String pref=sharedPreferences.getString("title","default");
        textview.setText(pref);
    }
}